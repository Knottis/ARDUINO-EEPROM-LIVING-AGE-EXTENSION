#ifndef EEPROMLivingAgeExtensionInt_h
#define EEPROMLivingAgeExtensionInt_h 

#include "Arduino.h" 
#include "EEPROM.h"

class EEPROMLIVINGAGEINT{
 public:
  int EEPROMLIVINGAGEINTREAD(int& , int&, int&, int* );
  int EEPROMLIVINGAGEINTWRITE(int& , int&, int&, int* );
  int EEPROMLIVINGAGEINTLIFECOUNTDOWN(int& , int&, int&, long& );
};
extern EEPROMLIVINGAGEINT EEPROMLivingAgeExtensionInt;  
#endif
