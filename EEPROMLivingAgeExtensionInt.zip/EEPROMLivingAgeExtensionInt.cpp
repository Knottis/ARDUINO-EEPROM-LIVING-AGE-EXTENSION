/*
 ==========================================================================================
 ===========    DATA TO EEPROM MAX LIVING AGE Libraries MODUL    CODE FILE ================
 ====================================================  Ver 1.02 - ATmega ALL OPTIMIZATION =
 ==========================================================================================
 
                      EEPROM LIVING AGE EXTENSION - INT
   
     Copyright (c) 01.27.2018 , Stein Barlund, sbarlundl@hotmail.com
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:
  
  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.
  
   
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
  THE SOFTWARE.
  
 
 Revisions are now tracked on GitHub
 https://github.com/

 Version 1.02: Support All ATmega moduls.

 ===============================================================================================================================
 int EEPROMADRESS = 0;          // Start adressess for data. 0 -> 1023++..
 int EEPROMADRESS_LAST = 1023;  // End adressess for data.   0 -> 1023++.. 
 int DATASIZEWITHINEEPROM = 1;  // Number Data Arrays[]...   0 -> 1023++..
 long DATAWITHINEEPROM[0];      // Quantity Data in Arrays[]... 0 -> 1023++.. LONG- "(+-) 2.147.483.648"
 long LIFECOUNTDOWN = 0;        // Return the number of Life for the EEPROM cells!... EEPROM LIFECOUNTDOWN = 12.800.000
 ===============================================================================================================================
 EEPROMLivingAgeExtension.EEPROMLIVINGAGEWRITE( EEPROMADRESS, EEPROMADRESS_LAST, DATAWITHINEEPROM );
 EEPROMLivingAgeExtension.EEPROMLIVINGAGESREAD( EEPROMADRESS, EEPROMADRESS_LAST, DATASIZEWITHINEEPROM, DATAWITHINEEPROM ); 
 EEPROMLivingAgeExtension.EEPROMLIVINGAGELIFECOUNTDOWN( EEPROMADRESS, EEPROMADRESS_LAST, DATASIZEWITHINEEPROM, LIFECOUNTDOWN );
 ===============================================================================================================================
*/

#include "Arduino.h"
#include "EEPROM.h"           
#include "EEPROMLivingAgeExtensionInt.h"

//==============================================================================================
//===============                         Initialization                         ===============
//==============================================================================================
//==============================================================================================
// PS:.. An EEPROM write takes '3.3 ms' to complete. The EEPROM memory has a specified life 
// of 100,000 write/erase cycles, so you may need to be careful about how often you write to it.
//==============================================================================================
long EEPROMLivingAgeExtensionGLOBAL = 100000;    // Max Life for EEPROM cellen!... 100.000-life.
//==============================================================================================
// EEPROM 4-bytes.  => ADRESSESS.
long EEPROMBIT4;
long EEPROMBIT3;
long EEPROMBIT2;
long EEPROMBIT1;
// EEPROM 4-bytes bitshifts. => DATA.
int EEPROMDECOMPBIT2;
int EEPROMDECOMPBIT1;
//==============================================================================================
long ADRESSENWITHINEEPROM = 0;
int EEPROM_LENGTH = 0;
int EEPROMLAE_i = 0;
long EEPROMLAE_x = 0;
//==============================================================================================


void SmartDelay_EEPROMLivingAgeExtensionInt()
{
  unsigned long CurrentMillis = 0;
  CurrentMillis = millis();
  do 
  {
  // WAIT 3.3 ms SO EEPROM IS FINISH TO WRITE TO MEMMORY. 
  } while (millis() - CurrentMillis < 4);
}



int EEPROMLIVINGAGEINT::EEPROMLIVINGAGEINTREAD(int& EEPROMADRESS, int& EEPROMADRESS_LAST, int& DATASIZEWITHINEEPROM, int* DATAWITHINEEPROM )
{
ADRESSENWITHINEEPROM = 0;
EEPROMLAE_i = 0;
EEPROM_LENGTH = (EEPROM.length() - 4 - DATASIZEWITHINEEPROM );

Serial.print("EEPROM_LENGTH = ");
Serial.println(EEPROM_LENGTH);

if (EEPROM_LENGTH < 0){
  return 1;                                 // EXIT...
}
else{
NewEEPROMLIVINGAGESREAD:
EEPROMBIT4 = EEPROM.read(EEPROMADRESS);
EEPROMBIT3 = EEPROM.read(EEPROMADRESS +1);
EEPROMBIT2 = EEPROM.read(EEPROMADRESS +2);
EEPROMBIT1 = EEPROM.read(EEPROMADRESS +3);
ADRESSENWITHINEEPROM = ( ((EEPROMBIT4 << 0) & 0xFF) + ((EEPROMBIT3 << 8) & 0xFFFF) + ((EEPROMBIT2 << 16) & 0xFFFFFF) + ((EEPROMBIT1 << 24) & 0xFFFFFFFF) ); 
 if ( ADRESSENWITHINEEPROM <= EEPROMLivingAgeExtensionGLOBAL ){
   EEPROMADRESS = EEPROMADRESS + 4; 
   for ( EEPROMLAE_i=0; EEPROMLAE_i < DATASIZEWITHINEEPROM; EEPROMLAE_i++ ){
    EEPROMDECOMPBIT2 = byte(EEPROM.read(EEPROMADRESS));
    EEPROMDECOMPBIT1 = byte(EEPROM.read(EEPROMADRESS +1));
    DATAWITHINEEPROM[EEPROMLAE_i] = ( ((EEPROMDECOMPBIT2 << 0) & 0xFF) + ((EEPROMDECOMPBIT1 << 8) & 0xFFFF) );    
    EEPROMADRESS = EEPROMADRESS + 2;
   }  
   return 0;                                               // Everything is OK...
  }
else{
    EEPROMADRESS = ((EEPROMADRESS + 4) + DATASIZEWITHINEEPROM );
    if ( EEPROMADRESS < EEPROM_LENGTH && ((EEPROMADRESS + 4) + DATASIZEWITHINEEPROM ) <= EEPROMADRESS_LAST  ){
      goto NewEEPROMLIVINGAGESREAD;
    }
    else{
      EEPROMADRESS = (EEPROMADRESS - DATASIZEWITHINEEPROM ); 
      for ( EEPROMLAE_i=0; EEPROMLAE_i < DATASIZEWITHINEEPROM; EEPROMLAE_i++ ){
       EEPROMDECOMPBIT2 = byte(EEPROM.read(EEPROMADRESS));
       EEPROMDECOMPBIT1 = byte(EEPROM.read(EEPROMADRESS +1));
       DATAWITHINEEPROM[EEPROMLAE_i] = ( ((EEPROMDECOMPBIT2 << 0) & 0xFF) + ((EEPROMDECOMPBIT1 << 8) & 0xFFFF) );    
       EEPROMADRESS = EEPROMADRESS + 2;                     // Int stores a 16-bit (2-byte) value.
      }            
      return 1;                                             // Memory error!!!...MAX SIZE!..
    }
  }
 }
}



int EEPROMLIVINGAGEINT::EEPROMLIVINGAGEINTWRITE(int& EEPROMADRESS, int& EEPROMADRESS_LAST, int& DATASIZEWITHINEEPROM, int* DATAWITHINEEPROM )
{
ADRESSENWITHINEEPROM = 0;
EEPROMLAE_i = 0;
EEPROMLAE_x = 0;
EEPROM_LENGTH = (EEPROM.length() - 4 - DATASIZEWITHINEEPROM );
if (EEPROM_LENGTH < 0 && EEPROMADRESS < EEPROM_LENGTH && ((EEPROMADRESS + 4) + DATASIZEWITHINEEPROM ) <= EEPROMADRESS_LAST ){
  return 1;                                                    // EXIT...
}
else{
NewEEPROMLIVINGAGEWRITE: 
EEPROMBIT4 = EEPROM.read(EEPROMADRESS);
EEPROMBIT3 = EEPROM.read(EEPROMADRESS +1);
EEPROMBIT2 = EEPROM.read(EEPROMADRESS +2);
EEPROMBIT1 = EEPROM.read(EEPROMADRESS +3);
ADRESSENWITHINEEPROM = ( ((EEPROMBIT4 << 0) & 0xFF) + ((EEPROMBIT3 << 8) & 0xFFFF) + ((EEPROMBIT2 << 16) & 0xFFFFFF) + ((EEPROMBIT1 << 24) & 0xFFFFFFFF) ); // Les inn første adressen = 0 -> 409...

 if ( ADRESSENWITHINEEPROM <= EEPROMLivingAgeExtensionGLOBAL ){

   if (ADRESSENWITHINEEPROM == EEPROMLivingAgeExtensionGLOBAL){                                

     ADRESSENWITHINEEPROM++;
     EEPROMBIT4 = (ADRESSENWITHINEEPROM  & 0xFF);
     EEPROMBIT3 = ((ADRESSENWITHINEEPROM >> 8) & 0xFFFF);
     EEPROMBIT2 = ((ADRESSENWITHINEEPROM << 16) & 0xFFFFFF);
     EEPROMBIT1 = ((ADRESSENWITHINEEPROM << 24) & 0xFFFFFFFF);
     EEPROM.write(EEPROMADRESS, EEPROMBIT4);
     SmartDelay_EEPROMLivingAgeExtensionInt();                 // An EEPROM write takes '3.3 ms' to complete...
     EEPROM.write(EEPROMADRESS +1, EEPROMBIT3); 
     SmartDelay_EEPROMLivingAgeExtensionInt();                 // An EEPROM write takes '3.3 ms' to complete...
     EEPROM.write(EEPROMADRESS +2, EEPROMBIT2); 
     SmartDelay_EEPROMLivingAgeExtensionInt();                 // An EEPROM write takes '3.3 ms' to complete...
     EEPROM.write(EEPROMADRESS +3, EEPROMBIT1);        
     SmartDelay_EEPROMLivingAgeExtensionInt();                 // An EEPROM write takes '3.3 ms' to complete...
     goto NewEEPROMLIVINGAGEWRITE;
   }        
   ADRESSENWITHINEEPROM++;                                        

   EEPROMBIT4 = (ADRESSENWITHINEEPROM & 0xFF);
   EEPROMBIT3 = ((ADRESSENWITHINEEPROM >> 8) & 0xFFFF);
   EEPROMBIT2 = ((ADRESSENWITHINEEPROM << 16) & 0xFFFFFF);
   EEPROMBIT1 = ((ADRESSENWITHINEEPROM << 24) & 0xFFFFFFFF);
   EEPROM.write(EEPROMADRESS, EEPROMBIT4);
   SmartDelay_EEPROMLivingAgeExtensionInt();                  // An EEPROM write takes '3.3 ms' to complete...
   EEPROM.write(EEPROMADRESS +1, EEPROMBIT3);
   SmartDelay_EEPROMLivingAgeExtensionInt();                  // An EEPROM write takes '3.3 ms' to complete...
   EEPROM.write(EEPROMADRESS +2, EEPROMBIT2); 
   SmartDelay_EEPROMLivingAgeExtensionInt();                  // An EEPROM write takes '3.3 ms' to complete...
   EEPROM.write(EEPROMADRESS +3, EEPROMBIT1);
   SmartDelay_EEPROMLivingAgeExtensionInt();                  // An EEPROM write takes '3.3 ms' to complete...
   EEPROMADRESS = EEPROMADRESS + 4;

   for (EEPROMLAE_i=0; EEPROMLAE_i < DATASIZEWITHINEEPROM; EEPROMLAE_i++ ){
    EEPROMLAE_x = 0;
    EEPROMLAE_x = DATAWITHINEEPROM[EEPROMLAE_i];
    EEPROMDECOMPBIT2 = (EEPROMLAE_x & 0xFF);
    EEPROMDECOMPBIT1 = ((EEPROMLAE_x >> 8) & 0xFF);    
    EEPROM.write(EEPROMADRESS, byte(EEPROMDECOMPBIT2));       // Write a byte(0-256) to the EEPROM...
    SmartDelay_EEPROMLivingAgeExtensionInt();                 // An EEPROM write takes '3.3 ms' to complete...
    EEPROM.write(EEPROMADRESS +1, byte(EEPROMDECOMPBIT1));    // Write a byte(0-256) to the EEPROM...
    SmartDelay_EEPROMLivingAgeExtensionInt();                 // An EEPROM write takes '3.3 ms' to complete...
    EEPROMADRESS = EEPROMADRESS + 2;                          // Int stores a 16-bit (2-byte) value.                     
   }     
   return 0;                                                  // Everything is OK...
 }
  else{
    EEPROMADRESS = ( (EEPROMADRESS + 4) + DATASIZEWITHINEEPROM );
    if ( EEPROMADRESS < EEPROM_LENGTH && ((EEPROMADRESS + 4) + DATASIZEWITHINEEPROM) <= EEPROMADRESS_LAST ) {
      goto NewEEPROMLIVINGAGEWRITE;
    }
    else{                                                      
      return 1;                                               // Memory error!!!...MAX SIZE!..
    }
  }
 }
}



int EEPROMLIVINGAGEINT::EEPROMLIVINGAGEINTLIFECOUNTDOWN(int& EEPROMADRESS, int& EEPROMADRESS_LAST, int& DATASIZEWITHINEEPROM, long& LIFECOUNTDOWN )
{
ADRESSENWITHINEEPROM = 0;
EEPROMLAE_i = 0;
EEPROM_LENGTH = ( (EEPROM.length() - 4) - DATASIZEWITHINEEPROM );
if (EEPROM_LENGTH < 0){
  return 1;                                                // EXIT
}
else{
NewEEPROMLIVINGAGESREAD: 
EEPROMBIT4 = EEPROM.read(EEPROMADRESS);
EEPROMBIT3 = EEPROM.read(EEPROMADRESS +1);
EEPROMBIT2 = EEPROM.read(EEPROMADRESS +2);
EEPROMBIT1 = EEPROM.read(EEPROMADRESS +3);
ADRESSENWITHINEEPROM = ( ((EEPROMBIT4 << 0) & 0xFF) + ((EEPROMBIT3 << 8) & 0xFFFF) + ((EEPROMBIT2 << 16) & 0xFFFFFF) + ((EEPROMBIT1 << 24) & 0xFFFFFFFF) );
 if ( ADRESSENWITHINEEPROM <= EEPROMLivingAgeExtensionGLOBAL ){
   if (EEPROMADRESS == 0){
   EEPROMADRESS_LAST++;                                         // 0-1023. Because of Eprom.Length = >1-1024       
   }
   else{
   EEPROMADRESS++;                                              // 0-1023. Because of Eprom.Length = >1-1024
   EEPROMADRESS_LAST++;                                         // 0-1023. Because of Eprom.Length = >1-1024  
   }  
   LIFECOUNTDOWN = EEPROMADRESS_LAST - EEPROMADRESS;
   LIFECOUNTDOWN = LIFECOUNTDOWN * EEPROMLivingAgeExtensionGLOBAL;
   LIFECOUNTDOWN = LIFECOUNTDOWN / (4+ (DATASIZEWITHINEEPROM * 2) );  //BYTES => Int stores a 16-bit (2-byte) value. 
   LIFECOUNTDOWN = LIFECOUNTDOWN - ADRESSENWITHINEEPROM;
   return 0;                                                    // Everything is OK...
  }
else{
    EEPROMADRESS = ((EEPROMADRESS + 4) + DATASIZEWITHINEEPROM );   
    if ( EEPROMADRESS < EEPROM_LENGTH && ((EEPROMADRESS + 4) + DATASIZEWITHINEEPROM ) <= EEPROMADRESS_LAST  ){
      goto NewEEPROMLIVINGAGESREAD;
    }
    else{
      LIFECOUNTDOWN = ( ( (EEPROMADRESS_LAST - EEPROMADRESS) / (4 + DATASIZEWITHINEEPROM ) * EEPROMLivingAgeExtensionGLOBAL) ) - ADRESSENWITHINEEPROM ;  // * Specified life of 100,000 write/erase cycles.
      return 1;                                                 //  Memory error!!!...MAX SIZE!..
    }
  }
 }
}



EEPROMLIVINGAGEINT EEPROMLivingAgeExtensionInt;
