#ifndef EEPROMLivingAgeExtension_h
#define EEPROMLivingAgeExtension_h 

#include "Arduino.h" 
#include "EEPROM.h"

class EEPROMLIVINGAGE{
 public:
  int EEPROMLIVINGAGEREAD(int&, int&, int&, long* );
  int EEPROMLIVINGAGEWRITE(int&, int&, int&, long* );
  int EEPROMLIVINGAGELIFECOUNTDOWN(int&, int&, int&, long& );
};
extern EEPROMLIVINGAGE EEPROMLivingAgeExtension;  
#endif
